@echo off
setlocal
cd /d "%~dp0"
title petalwave
echo.
echo   petalwave
echo   =========
echo.

rem ---- aviso si lo abrio sin descomprimir el zip ----
echo %~dp0 | find /i "Temp1_" >nul
if not errorlevel 1 goto :sinzip

call :refreshpath

rem ---- 1. revisar que este todo instalado ----
set "FALTA="
where node >nul 2>nul || set "FALTA=1"
where yt-dlp >nul 2>nul || set "FALTA=1"
where ffmpeg >nul 2>nul || set "FALTA=1"
if not exist "lib\py\ytmusicapi" set "FALTA=1"
if not defined FALTA goto :ventana

echo  Primera vez: voy a instalar lo que falta. Puede tardar unos minutos.
echo  Si Windows te pregunta algo, di que SI. No cierres esta ventana.
echo.
where winget >nul 2>nul
if errorlevel 1 goto :sinwinget
call instalar.bat auto
call :refreshpath
where node >nul 2>nul
if errorlevel 1 goto :reabrir

rem ---- 2. crear la ventana de petalwave (una sola vez) ----
:ventana
if exist petalwave.exe goto :atajo
echo  Creando la ventana de petalwave...
call build.bat

rem ---- 3. acceso directo en el escritorio (una sola vez) ----
:atajo
if not exist petalwave.exe goto :navegador
if not exist data mkdir data
if exist "data\.atajo" goto :abrir
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\petalwave.lnk');$s.TargetPath='%~dp0petalwave.exe';$s.WorkingDirectory='%~dp0';$s.IconLocation='%~dp0build\icon.ico';$s.Save()" >nul 2>nul
echo ok> "data\.atajo"
echo  Listo: te deje un acceso directo "petalwave" en el escritorio.

:abrir
start "" petalwave.exe
exit /b 0

rem ---- si no se pudo crear la ventana, usar el navegador ----
:navegador
echo  No se pudo crear la ventana, abro petalwave en tu navegador.
node server.js
pause
exit /b 0

:sinzip
echo  Primero tenes que EXTRAER el zip.
echo  Clic derecho sobre el archivo .zip, "Extraer todo...", y abri Empezar.bat desde la carpeta nueva.
echo.
pause
exit /b 1

:sinwinget
echo  Tu Windows no tiene "winget", que uso para instalar lo necesario.
echo  Instala a mano estos tres programas y vuelve a abrir Empezar.bat:
echo    Node.js  https://nodejs.org
echo    yt-dlp   https://github.com/yt-dlp/yt-dlp/releases
echo    ffmpeg   https://www.gyan.dev/ffmpeg/builds
echo.
pause
exit /b 1

:reabrir
echo.
echo  Se instalo todo, pero Windows necesita que abras Empezar.bat otra vez.
echo  Cierra esta ventana y vuelve a hacer doble clic en Empezar.bat.
echo.
pause
exit /b 1

:refreshpath
for /f "usebackq delims=" %%p in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('Path','Machine')+';'+[Environment]::GetEnvironmentVariable('Path','User')"`) do set "PATH=%%p;%PATH%"
exit /b 0
