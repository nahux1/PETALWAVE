#!/usr/bin/env sh
# Arranca petalwave en Linux / macOS (necesita Node.js 18+, yt-dlp y ffmpeg en el PATH).
cd "$(dirname "$0")" || exit 1
command -v node >/dev/null 2>&1 || { echo "No se encontro Node.js (https://nodejs.org)"; exit 1; }
exec node server.js
