@echo off
setlocal
cd /d "%~dp0"
title petalwave - instalacion
echo.
echo  petalwave - instalacion de dependencias (una sola vez)
echo  ======================================================
echo.

rem ---------- 1. Node.js ----------
where node >nul 2>nul
if errorlevel 1 (
  echo [1/4] Instalando Node.js...
  winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
  set "NEWPATH=1"
) else (
  echo [1/4] Node.js ya esta instalado.
)

rem ---------- 2. yt-dlp y ffmpeg ----------
where yt-dlp >nul 2>nul
if errorlevel 1 (
  echo [2/4] Instalando yt-dlp...
  winget install --id yt-dlp.yt-dlp -e --accept-source-agreements --accept-package-agreements
) else (
  echo [2/4] yt-dlp ya esta instalado.
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo [3/4] Instalando ffmpeg...
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
) else (
  echo [3/4] ffmpeg ya esta instalado.
)

rem ---------- 3. Python 3.10+ y ytmusicapi (YouTube Music) ----------
echo [4/4] Preparando ytmusicapi (YouTube Music)...
set "PY="
python -c "import sys;sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul && set "PY=python"
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PY (
  echo       Python 3.10 o superior no encontrado, instalando Python 3.12...
  winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if defined PY (
  "%PY%" -m pip install --upgrade --target lib\py -r requirements.txt
) else (
  echo       No se pudo preparar Python. Instalalo desde https://www.python.org y volve a ejecutar este archivo.
  echo       Sin esto petalwave funciona igual, pero sin busqueda ni me gusta de YouTube Music.
)

echo.
echo  Listo. Si se instalo algo nuevo, cerra y volve a abrir esta ventana antes de continuar.
echo  Despues ejecuta iniciar.bat  (o build.bat para crear petalwave.exe).
echo.
pause
